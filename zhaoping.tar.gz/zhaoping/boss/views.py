from django.shortcuts import render
import datetime

# Create your views here.
from boss import models
from boss.models import Shuju


def first(request):
    # thing = request.POST.get('smk')
    # date_now = datetime.datetime.now()
    # pkid = request.POST.get('ids','0')
    # datas =str(date_now.year) + '年' + str(date_now.month) +'月' + str(date_now.day) +'日' + str(date_now.hour) + '点'
    #
    # Shuju.objects.create(data=datas,things=thing)
    shuju = Shuju.objects.all()

    return render(request,'ren.html',{'shuju':shuju})


def index(request):
    shuju = Shuju()
    thing = request.POST['msg']
    date_now = datetime.datetime.now()
    pkid = request.POST.get('ids','0')
    datas =str(date_now.year) + '年' + str(date_now.month) +'月' + str(date_now.day) +'日' + str(date_now.hour) + '点'
    shuju.things = thing
    shuju.data = datas
    shuju.save()

    shuju = Shuju.objects.all()
    return render(request,'ren.html',{'shuju':shuju})