from django.db import models

# Create your models here.
class Shuju(models.Model):

    things = models.CharField(max_length=1000,null=True)
    data = models.CharField(max_length=50,null=True)
