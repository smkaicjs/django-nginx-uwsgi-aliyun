from django.conf.urls import url

from boss import views


urlpatterns = [
    url('pinglun/',views.first),
    url('index/',views.index,name='indexs')
]