from django.apps import AppConfig


class BossConfig(AppConfig):
    name = 'boss'
